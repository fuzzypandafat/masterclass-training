import os
from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain_core.documents import Document
from langchain_text_splitters import CharacterTextSplitter
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_community.document_loaders import (
    CSVLoader,
    PyPDFLoader,
    UnstructuredMarkdownLoader,
)
import environ
from logging_config import get_logger

# Initialize logger
logger = get_logger(__name__)

env = environ.Env()
# reading .env file
environ.Env.read_env()

llm = ChatOpenAI(
    model="gpt-4o-mini",
    api_key=env("OPENAI_API_KEY"),
)

embeddings = OpenAIEmbeddings(
    api_key=env("OPENAI_API_KEY"),
)

text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)


def load_document(file_path: str) -> list[Document]:
    """
    Load a document from a file path.
    Supports .pdf, .csv, and .md files.

    Args:
    file_path (str): Path to the document file.

    Returns:
    list[Document]: A list of Document objects.

    Raises:
    ValueError: If the file type is not supported.
    """
    logger.info(f"Loading document from {file_path}")
    _, file_extension = os.path.splitext(file_path)

    try:
        if file_extension == ".pdf":
            loader = PyPDFLoader(file_path)
        elif file_extension == ".csv":
            loader = CSVLoader(file_path)
        elif file_extension == ".md":
            loader = UnstructuredMarkdownLoader(file_path)
        else:
            raise ValueError(f"Unsupported file type: {file_extension}")

        documents = loader.load()
        logger.info(f"Successfully loaded document from {file_path}")
        return documents
    except Exception as e:
        logger.error(f"Error loading document from {file_path}: {e}", exc_info=True)
        raise RuntimeError(f"Error loading {file_path}") from e


def create_collection(collection_name, documents):
    """
    Create a new Chroma collection from the given documents.

    Args:
    collection_name (str): The name of the collection to create.
    documents (list): A list of documents to add to the collection.

    Returns:
    None

    This function splits the documents into texts, creates a new Chroma collection,
    and persists it to disk.
    """
    # Split the documents into smaller text chunks
    texts = text_splitter.split_documents(documents)
    persist_directory = "./persist"

    # Create a new Chroma collection from the text chunks
    try:
        vectordb = Chroma.from_documents(
            documents=texts,
            embedding=embeddings,
            persist_directory=persist_directory,
            collection_name=collection_name,
        )
    except Exception as e:
        print(f"Error creating collection: {e}")
        return None

    return vectordb


def load_collection(collection_name):
    """
    Load an existing Chroma collection.

    Args:
    collection_name (str): The name of the collection to load.

    Returns:
    Chroma: The loaded Chroma collection.

    This function loads a previously created Chroma collection from disk.
    """
    persist_directory = "./persist"
    # Load the Chroma collection from the specified directory
    vectordb = Chroma(
        persist_directory=persist_directory,
        embedding_function=embeddings,
        collection_name=collection_name,
    )

    return vectordb


def load_retriever(collection_name, score_threshold: float = 0.6):
    """
    Create a retriever from a Chroma collection with a similarity score threshold.

    Args:
    collection_name (str): The name of the collection to use.
    score_threshold (float): The minimum similarity score threshold for retrieving documents.
                           Documents with scores below this threshold will be filtered out.
                           Defaults to 0.6.

    Returns:
    Retriever: A retriever object that can be used to query the collection with similarity
              score filtering.

    This function loads a Chroma collection and creates a retriever from it that will only
    return documents meeting the specified similarity score threshold.
    """
    # Load the Chroma collection
    vectordb = load_collection(collection_name)
    # Create a retriever from the collection with specified search parameters
    retriever = vectordb.as_retriever(
        search_type="similarity_score_threshold",
        search_kwargs={"score_threshold": score_threshold},
    )
    return retriever


def generate_answer_from_context(retriever, question: str):
    """
    Ask a question and get an answer based on the provided context.

    Args:
        retriever: A retriever object to fetch relevant context.
        question (str): The question to be answered.

    Returns:
        str: The answer to the question based on the retrieved context.
    """
    # Define the message template for the prompt
    message0 = """
    Answer this question using the provided context only.

    {question}

    Context:
    {context}
    """
    message = """
    You are an advanced AI assistant integrated within a Retrieval Augmented Generation (RAG) system. Your primary goal is to provide accurate, information-based answers using only the details supplied. Follow these guidelines precisely:

    1. General Behavior and Integrity
    Accuracy: Base all responses solely on the provided information. Do not generate or speculate beyond the supplied data.
    Neutral Tone: Always maintain a neutral and professional tone.
    Clarification First: When details are unclear or missing, ask for clarification rather than making assumptions.
    Sensitive Topics: For sensitive matters, add: “For authoritative guidance, I recommend consulting [relevant expert/source].”
    
    2. Handling Inadequate or Problematic Information
        No Information Provided:
        Response: “I don't have enough information to answer that. Could you please provide more details or clarify your question?”
        
        Unrelated or Mismatched Information:
        Acknowledge Mismatch: “I have information related to [general topic], but it doesn’t specifically address your question.”
        Offer Alternatives: “Would you like me to:
        Share general knowledge on this topic, or
        Help refine your question?”
        
        Partial or Insufficient Information:
        Provide What’s Known: “Based on the available details, here’s a summary: [brief summary].”
        Request More Details: “I'm missing some specifics to fully answer your question. Would you like suggestions on what additional information might help?”
        
        Ambiguous Queries:
        Seek Clarity: “Could you clarify what you mean by [specific phrase/concept]? Understanding [specific aspect] would help me provide a better answer.”
        
        Conflicting Information:
        Address Differences: “There appear to be different perspectives on this topic.”
        Offer Choices: “Would you like me to:
        Explain the different viewpoints, or
        Focus on the most widely accepted perspective?”
        
        Out-of-Scope or Outdated Information:
        State Limitations: “My current information focuses on [specified timeframe/scope].”
        Offer Alternatives: “Would you like me to:
        Answer based on what I know, or
        Suggest where to find updated details?”
    
    3. Fallback Protocol
    If none of the above cases apply or if the query remains unclear:
    Prompt: “Let me try to rephrase that – are you asking about [interpretation 1] or [interpretation 2]? If this doesn't help, could you please rephrase your question?”
    
    4. User Engagement and Clarity
    Numbered Options: When offering alternatives or follow-up questions, use numbered lists to clearly present choices.
    Guiding the Conversation: Always steer the conversation toward a resolvable query that aligns with the provided information.
    
    5. Avoiding Technical Jargon
    No “Context” Mention: Do not explicitly reference the term “context” when interacting with the user. Instead, refer to “the available information” or “the details provided.”

    Answer this question using the provided context only.

    {question}

    Context:
    {context}

    """
    # Create a chat prompt template from the message
    prompt = ChatPromptTemplate.from_messages([("human", message)])

    # Create a RAG (Retrieval-Augmented Generation) chain
    # This chain retrieves context, passes through the question,
    # formats the prompt, and generates an answer using the language model
    rag_chain = {"context": retriever, "question": RunnablePassthrough()} | prompt | llm

    # Invoke the RAG chain with the question and return the generated content
    return rag_chain.invoke(question).content


def add_documents_to_collection(vectordb, documents):
    """
    Add documents to the vector database collection.

    Args:
        vectordb: The vector database object to add documents to.
        documents: A list of documents to be added to the collection.

    This function splits the documents into smaller chunks, adds them to the
    vector database, and persists the changes.
    """

    # Split the documents into smaller text chunks
    texts = text_splitter.split_documents(documents)

    # Add the text chunks to the vector database
    vectordb.add_documents(texts)

    return vectordb
