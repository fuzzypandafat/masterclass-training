import streamlit as st
from dotenv import load_dotenv
import os
from openai import AzureOpenAI

load_dotenv()

client = AzureOpenAI(
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),  
    api_version="2024-02-01",
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT")
)

st.title("🦜🔗 Langchain Quickstart App")

def generate_response(input_text):
    response = client.chat.completions.create(
        model="gpt-4o-mini",  # Match the model name from Chatbot.py
        messages=[{"role": "user", "content": input_text}]
    )
    st.info(response.choices[0].message.content)

with st.form("my_form"):
    text = st.text_area("Enter text:", "What are 3 key advice for learning how to code?")
    submitted = st.form_submit_button("Submit")
    if not os.getenv("AZURE_OPENAI_API_KEY"):
        st.info("Please set your Azure OpenAI credentials in the environment file.")
    elif submitted:
        generate_response(text)
